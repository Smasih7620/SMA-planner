package ir.maaih.planner
import android.Manifest
import android.annotation.SuppressLint
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import java.time.*

object Notifs {
    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rem", "یادآوری‌ها", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("mood", "حال و هوا", NotificationManager.IMPORTANCE_HIGH))
    }
    fun openChannel(c: Context, id: String) {
        channels(c)
        c.startActivity(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName).putExtra(Settings.EXTRA_CHANNEL_ID, id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    fun openApp(c: Context) = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    fun action(c: Context, code: Int, label: String, cls: Class<*>, id: Long, a: String): NotificationCompat.Action {
        val pi = PendingIntent.getBroadcast(c, code, Intent(c, cls).putExtra("i", id).putExtra("a", a), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Action.Builder(0, label, pi).build()
    }
    fun post(c: Context, chan: String, id: Int, title: String, body: String, content: PendingIntent, icon: Int,
             actions: List<NotificationCompat.Action> = emptyList(), big: RemoteViews? = null, full: PendingIntent? = null, auto: Boolean = true) {
        channels(c)
        val rv = RemoteViews(c.packageName, R.layout.notif_card).apply { setImageViewBitmap(R.id.n_img, Card.bitmap(c, title, body)) }
        val b = NotificationCompat.Builder(c, chan).setSmallIcon(icon).setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle()).setCustomContentView(rv).setCustomHeadsUpContentView(rv).setCustomBigContentView(big ?: rv)
            .setAutoCancel(auto).setContentIntent(content).setPriority(NotificationCompat.PRIORITY_HIGH)
        actions.forEach { b.addAction(it) }
        if (full != null) b.setFullScreenIntent(full, true)
        c.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }
}

object Alarms {
    fun schedule(c: Context, at: Long, pi: PendingIntent) {
        val am = c.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }
    private fun pi(c: Context, r: Reminder) = PendingIntent.getBroadcast(c, (r.id % Int.MAX_VALUE).toInt(),
        Intent(c, AlarmReceiver::class.java).putExtra("i", r.id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun set(c: Context, r: Reminder) {
        if (r.at <= System.currentTimeMillis() || (r.done && r.repeat == 0)) return
        schedule(c, r.at, pi(c, r))
    }
    fun cancel(c: Context, r: Reminder) = c.getSystemService(AlarmManager::class.java).cancel(pi(c, r))
}

object MoodAlarms {
    private fun pi(c: Context, m: Int) = PendingIntent.getBroadcast(c, 900000 + m,
        Intent(c, MoodReceiver::class.java).putExtra("m", m), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun set(c: Context, m: Int) {
        var t = LocalDate.now().atTime(m / 60, m % 60)
        if (!t.isAfter(LocalDateTime.now().plusSeconds(5))) t = t.plusDays(1)
        Alarms.schedule(c, t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), pi(c, m))
    }
    fun cancel(c: Context, m: Int) = c.getSystemService(AlarmManager::class.java).cancel(pi(c, m))
    fun syncAll(c: Context) = Store.moodTimes(c).forEach { set(c, it) }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("i", 0); val r = Store.reminders(c).find { it.id == id } ?: return
        if (!r.done) Notifs.post(c, "rem", System.nanoTime().toInt(), "⏰ " + r.title, Jalali.fmt(r.at), Notifs.openApp(c), android.R.drawable.ic_lock_idle_alarm)
        Store.advance(c, id); ReminderWidget.refresh(c)
    }
}

class MoodReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        MoodAlarms.set(c, i.getIntExtra("m", 0))
        val pi = PendingIntent.getActivity(c, 1, Intent(c, MoodPromptActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val title = "😊 الان حالت چطوره؟"; val body = "یکی از حالت‌ها رو انتخاب کن"
        val big = RemoteViews(c.packageName, R.layout.notif_mood)
        big.setImageViewBitmap(R.id.n_img, Card.bitmap(c, title, body))
        val ids = intArrayOf(R.id.n_m0, R.id.n_m1, R.id.n_m2, R.id.n_m3, R.id.n_m4)
        for (k in 0..4) big.setOnClickPendingIntent(ids[k], PendingIntent.getBroadcast(c, 2000 + k, Intent(c, MoodPickReceiver::class.java).putExtra("lv", k), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        Notifs.post(c, "mood", 777, title, body, pi, android.R.drawable.ic_dialog_info, big = big, full = pi)
    }
}

class MoodPickReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.addMood(c, LocalDate.now().toEpochDay(), i.getIntExtra("lv", 2))
        c.getSystemService(NotificationManager::class.java).cancel(777)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.normalize(c); Store.reminders(c).forEach { Alarms.set(c, it) }; MoodAlarms.syncAll(c); Geo.syncAll(c); ReminderWidget.refresh(c)
    }
}

object Geo {
    private fun pi(c: Context) = PendingIntent.getBroadcast(c, 5, Intent(c, GeoReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
    @SuppressLint("MissingPermission")
    fun add(c: Context, r: Reminder) {
        if (r.trig == 0 || r.done || c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val g = Geofence.Builder().setRequestId(r.id.toString()).setCircularRegion(r.lat, r.lng, r.rad.toFloat())
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT).build()
        LocationServices.getGeofencingClient(c).addGeofences(GeofencingRequest.Builder().setInitialTrigger(0).addGeofence(g).build(), pi(c))
    }
    fun remove(c: Context, r: Reminder) { LocationServices.getGeofencingClient(c).removeGeofences(listOf(r.id.toString())) }
    fun syncAll(c: Context) = Store.reminders(c).forEach { add(c, it) }
}

class GeoReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val e = GeofencingEvent.fromIntent(i) ?: return
        if (e.hasError()) return
        val tr = e.geofenceTransition
        e.triggeringGeofences?.forEach { g ->
            val r = Store.reminders(c).find { it.id.toString() == g.requestId } ?: return@forEach
            if (r.done) return@forEach
            val match = (r.trig == 1 && tr == Geofence.GEOFENCE_TRANSITION_ENTER) || (r.trig == 2 && tr == Geofence.GEOFENCE_TRANSITION_EXIT)
            if (match) {
                if (!r.armed) return@forEach
                Store.update(c, r.copy(armed = false, again = false))
                val nid = (r.id % 1000000000L).toInt(); val rc = (r.id % 100000L).toInt() * 2
                Notifs.post(c, "rem", nid, (if (r.trig == 1) "📍 رسیدی! " else "📍 از اینجا خارج شدی! ") + r.title, "انجام شد رو بزن تا حذف بشه، یا «دوباره یادآوری کن» تا دفعه بعد هم بگم",
                    Notifs.openApp(c), android.R.drawable.ic_dialog_map,
                    listOf(Notifs.action(c, rc, "✅ انجام شد", GeoActionReceiver::class.java, r.id, "done"), Notifs.action(c, rc + 1, "🔁 دوباره یادآوری کن", GeoActionReceiver::class.java, r.id, "again")), auto = false)
            } else if (r.again && !r.armed) Store.update(c, r.copy(armed = true, again = false))
        }
    }
}

class GeoActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("i", 0)
        c.getSystemService(NotificationManager::class.java).cancel((id % 1000000000L).toInt())
        val r = Store.reminders(c).find { it.id == id } ?: return
        if (i.getStringExtra("a") == "done") { Geo.remove(c, r); Store.saveReminders(c, Store.reminders(c).filter { it.id != id }) }
        else Store.update(c, r.copy(again = true))
    }
}
