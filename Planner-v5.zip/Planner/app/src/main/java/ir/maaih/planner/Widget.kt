package ir.maaih.planner
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

class ReminderWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = refresh(c)
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == MODE) { c.getSharedPreferences("w", 0).edit().putInt("mode", i.getIntExtra("mode", 0)).apply(); refresh(c) }
        else super.onReceive(c, i)
    }
    companion object {
        const val MODE = "ir.maaih.planner.MODE"
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, ReminderWidget::class.java)); if (ids.isEmpty()) return
            val mode = c.getSharedPreferences("w", 0).getInt("mode", 0)
            val (f, t) = rangeOf(mode, 0)
            val items = Store.occurrences(Store.reminders(c), f.ms(), t.ms()).filter { !(it.first && it.r.done) }
            val rv = RemoteViews(c.packageName, R.layout.widget)
            rv.setTextViewText(R.id.w_title, Jalali.label(mode, f, t))
            val body = if (items.isEmpty()) "یادآوری‌ای نیست ✨" else
                items.take(8).joinToString("\n") { o ->
                    "• " + (if (mode == 0) Jalali.time(o.at) else Jalali.fmt(o.at)) + "  " + o.r.title + (if (mode == 0) "" else "  ⏳ " + Jalali.rel(o.at))
                } + (if (items.size > 8) "\n+ " + Jalali.fa(items.size - 8) + " مورد دیگر" else "")
            val nloc = Store.reminders(c).count { it.trig > 0 && !it.done }
            rv.setTextViewText(R.id.w_text, body + (if (nloc > 0) "\n📍 " + Jalali.fa(nloc) + " یادآوری مکانی فعال" else ""))
            val tabs = intArrayOf(R.id.w_m0, R.id.w_m1, R.id.w_m2)
            for (k in 0..2) {
                rv.setInt(tabs[k], "setBackgroundResource", if (k == mode) R.drawable.tab_on else R.drawable.tab_off)
                rv.setTextColor(tabs[k], if (k == mode) Color.WHITE else Color.BLACK)
                rv.setOnClickPendingIntent(tabs[k], PendingIntent.getBroadcast(c, 100 + k,
                    Intent(c, ReminderWidget::class.java).setAction(MODE).putExtra("mode", k), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            ids.forEach { m.updateAppWidget(it, rv) }
        }
    }
}
