package ir.maaih.planner
import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.widget.RemoteViews
import androidx.core.graphics.ColorUtils
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.*

class ClockWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = refresh(c)
    override fun onDisabled(c: Context) { c.getSystemService(AlarmManager::class.java).cancel(tickPi(c)) }
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == TICK) { refresh(c); ReminderWidget.refresh(c) } else super.onReceive(c, i)
    }
    private class Ev(val s: Float, val e: Float, val col: Int, val title: String)
    companion object {
        const val TICK = "ir.maaih.planner.TICK"
        private fun tickPi(c: Context) = PendingIntent.getBroadcast(c, 300, Intent(c, ClockWidget::class.java).setAction(TICK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, ClockWidget::class.java)); if (ids.isEmpty()) return
            c.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC, System.currentTimeMillis() + 300000, tickPi(c))
            val rv = RemoteViews(c.packageName, R.layout.widget_clock)
            rv.setImageViewBitmap(R.id.c_img, draw(c, 800))
            rv.setOnClickPendingIntent(R.id.c_img, PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            rv.setOnClickPendingIntent(R.id.c_center, PendingIntent.getActivity(c, 1,
                Intent(c, MainActivity::class.java).putExtra("add", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            ids.forEach { m.updateAppWidget(it, rv) }
        }
        private fun draw(c: Context, sz: Int): Bitmap {
            val bmp = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp)
            val cx = sz / 2f; val R = cx - 6f; val Rd = R * 0.90f; val rc = Rd * 0.36f; val rOut = Rd * 0.97f
            val homa = c.resources.getFont(R.font.homa); val titr = c.resources.getFont(R.font.titr)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = 0x80505560.toInt(); cv.drawCircle(cx, cx, R, p)
            p.style = Paint.Style.STROKE; p.color = 0xD9FFFFFF.toInt()
            for (i in 0 until 96) { val a = Math.toRadians(i * 3.75); val big = i % 4 == 0
                p.strokeWidth = if (big) 4.5f else 2.5f; val r1 = R - 5f; val r2 = r1 - (if (big) R * 0.055f else R * 0.03f)
                cv.drawLine(cx + (r1 * sin(a)).toFloat(), cx - (r1 * cos(a)).toFloat(), cx + (r2 * sin(a)).toFloat(), cx - (r2 * cos(a)).toFloat(), p) }
            p.style = Paint.Style.FILL; p.color = 0xFFF9F9F9.toInt(); cv.drawCircle(cx, cx, Rd, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x1A000000
            for (h in 0 until 24) { val a = Math.toRadians(h * 15.0)
                cv.drawLine(cx + (rc * sin(a)).toFloat(), cx - (rc * cos(a)).toFloat(), cx + (Rd * 0.98 * sin(a)).toFloat(), cx - (Rd * 0.98 * cos(a)).toFloat(), p) }
            p.style = Paint.Style.FILL
            val today = LocalDate.now(); val f = today.ms(); val t = today.plusDays(1).ms()
            val evs = Store.occurrences(Store.reminders(c), f - 86400000L, t).filter { it.r.trig == 0 && !(it.first && it.r.done) }.mapNotNull { o ->
                val s = maxOf(o.at, f); val e = minOf(o.at + o.r.dur * 60000L, t)
                if (e <= s) null else Ev((s - f) / 60000f, (e - f) / 60000f, o.r.col, o.r.title) }.sortedBy { it.s }
            val laneEnd = FloatArray(3); val lane = IntArray(evs.size)
            evs.forEachIndexed { i, e -> var k = 0; while (k < 2 && laneEnd[k] > e.s) k++; lane[i] = k; laneEnd[k] = max(laneEnd[k], e.e) }
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = homa; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
            evs.forEachIndexed { i, e ->
                val ov = evs.indices.filter { j -> evs[j].s < e.e && e.s < evs[j].e }
                val n = ov.maxOf { lane[it] } + 1
                val full = (e.e - e.s) / 1440f * 360f
                val a0 = e.s / 1440f * 360f - 90f + full * lane[i] / n; val sw = full / n
                val ri = rc - 2f
                val path = Path(); path.arcTo(RectF(cx - rOut, cx - rOut, cx + rOut, cx + rOut), a0, sw); path.arcTo(RectF(cx - ri, cx - ri, cx + ri, cx + ri), a0 + sw, -sw); path.close()
                val col = Palette[e.col.coerceIn(0, 9)].toInt(); p.color = col; cv.drawPath(path, p)
                val r0 = rc * 1.15f; val r1 = Rd * 0.76f; val rm = (r0 + r1) / 2f; val avail = r1 - r0 - 8f
                val ts = min(Rd * 0.095f, (Math.toRadians(sw.toDouble()) * rm).toFloat() * 0.72f)
                if (ts >= Rd * 0.04f && avail > 30f) {
                    tp.textSize = ts; tp.color = if (ColorUtils.calculateLuminance(col) > 0.5) 0xFF111111.toInt() else Color.WHITE
                    var txt = e.title; val cnt = tp.breakText(txt, true, avail, null); if (cnt < txt.length) txt = txt.substring(0, max(1, cnt - 1)) + "…"
                    val midTop = a0 + sw / 2f + 90f; val flip = midTop % 360f in 180f..360f
                    cv.save(); cv.translate(cx, cx); cv.rotate(midTop - 90f + (if (flip) 180f else 0f))
                    cv.drawText(txt, if (flip) -rm else rm, ts * 0.35f, tp); cv.restore()
                }
            }
            val now = LocalTime.now(); val haDeg = (now.hour * 60 + now.minute) / 1440f * 360f; val ha = Math.toRadians(haDeg.toDouble())
            p.style = Paint.Style.STROKE; p.strokeWidth = Rd * 0.028f; p.strokeCap = Paint.Cap.ROUND; p.color = 0xFFE53935.toInt()
            cv.drawLine(cx + (rc * sin(ha)).toFloat(), cx - (rc * cos(ha)).toFloat(), cx + (Rd * 0.985 * sin(ha)).toFloat(), cx - (Rd * 0.985 * cos(ha)).toFloat(), p)
            val np = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = homa; color = 0xFF222222.toInt(); textAlign = Paint.Align.CENTER; textSize = Rd * 0.095f; isFakeBoldText = true }
            for (h in 0 until 24) { val a = Math.toRadians(h * 15.0); val rr = Rd * 0.87
                cv.drawText(Jalali.fa(h), cx + (rr * sin(a)).toFloat(), cx - (rr * cos(a)).toFloat() + np.textSize * 0.35f, np) }
            p.style = Paint.Style.FILL; p.color = Color.WHITE; cv.drawCircle(cx, cx, rc, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = 0x22000000; cv.drawCircle(cx, cx, rc, p)
            p.strokeWidth = Rd * 0.045f; p.strokeCap = Paint.Cap.ROUND; p.color = 0xFF2B2B2B.toInt()
            cv.drawArc(RectF(cx - rc, cx - rc, cx + rc, cx + rc), haDeg - 90f, 360f - haDeg, false, p)
            val j = Jalali.of(today)
            val cp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = homa; color = 0xFF777777.toInt() }
            cp.textSize = rc * 0.16f; cv.drawText("SMA", cx, cx - rc * 0.55f, cp)
            cp.typeface = titr; cp.color = 0xFF111111.toInt(); cp.textSize = rc * 0.21f; cv.drawText(Jalali.dayName(today), cx, cx - rc * 0.22f, cp)
            cp.textSize = rc * 0.40f; cv.drawText(Jalali.fa("%02d:%02d".format(now.hour, now.minute)), cx, cx + rc * 0.30f, cp)
            cp.typeface = homa; cp.color = 0xFF444444.toInt(); cp.textSize = rc * 0.17f; cv.drawText(Jalali.fa("${j.third} ${Jalali.months[j.second - 1]} ${j.first}"), cx, cx + rc * 0.68f, cp)
            return bmp
        }
    }
}
