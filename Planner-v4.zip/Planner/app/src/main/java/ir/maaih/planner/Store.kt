package ir.maaih.planner
import android.content.Context
import org.json.*
import java.time.*

data class Reminder(val id: Long, val title: String, val at: Long, val done: Boolean = false, val repeat: Int = 0,
    val lat: Double = 0.0, val lng: Double = 0.0, val rad: Int = 0, val trig: Int = 0,
    val col: Int = 3, val dur: Int = 60)
data class Occ(val r: Reminder, val at: Long, val first: Boolean)
val Palette = longArrayOf(0xFFFF6B6B, 0xFFFF9F43, 0xFFFECA57, 0xFF1DD1A1, 0xFF10AC84, 0xFF48DBFB, 0xFF54A0FF, 0xFFA29BFE, 0xFFF368E0, 0xFFFD79A8)
fun LocalDate.ms() = atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

fun rangeOf(mode: Int, off: Int): Pair<LocalDate, LocalDate> {
    val t = LocalDate.now()
    return when (mode) {
        0 -> t.plusDays(off.toLong()).let { it to it.plusDays(1) }
        1 -> { val s = t.minusDays(((t.dayOfWeek.value + 1) % 7).toLong()).plusWeeks(off.toLong()); s to s.plusDays(7) }
        else -> {
            val j = Jalali.of(t); var y = j.first; var m = j.second + off
            while (m > 12) { m -= 12; y++ }; while (m < 1) { m += 12; y-- }
            Jalali.toDate(y, m, 1) to Jalali.toDate(if (m == 12) y + 1 else y, if (m == 12) 1 else m + 1, 1)
        }
    }
}

object Store {
    private fun p(c: Context) = c.getSharedPreferences("d", 0)
    fun reminders(c: Context): List<Reminder> {
        val a = JSONArray(p(c).getString("r", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it); Reminder(o.getLong("id"), o.getString("t"), o.getLong("a"), o.getBoolean("d"), o.optInt("p", 0), o.optDouble("la", 0.0), o.optDouble("lo", 0.0), o.optInt("ra", 0), o.optInt("tg", 0), o.optInt("co", 3).coerceIn(0, 9), o.optInt("du", 60)) }.sortedBy { it.at }
    }
    fun saveReminders(c: Context, l: List<Reminder>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("id", it.id).put("t", it.title).put("a", it.at).put("d", it.done).put("p", it.repeat).put("la", it.lat).put("lo", it.lng).put("ra", it.rad).put("tg", it.trig).put("co", it.col).put("du", it.dur)) }
        p(c).edit().putString("r", a.toString()).apply(); ReminderWidget.refresh(c); ClockWidget.refresh(c)
    }
    fun nextAt(r: Reminder): Long {
        val z = ZoneId.systemDefault(); val t = LocalDateTime.ofInstant(Instant.ofEpochMilli(r.at), z)
        val n = when (r.repeat) {
            1 -> t.plusDays(1); 2 -> t.plusWeeks(1)
            else -> { val j = Jalali.of(t.toLocalDate()); var y = j.first; var m = j.second + 1; if (m > 12) { m = 1; y++ }
                LocalDateTime.of(Jalali.toDate(y, m, minOf(j.third, Jalali.monthLen(y, m))), t.toLocalTime()) }
        }
        return n.atZone(z).toInstant().toEpochMilli()
    }
    fun advance(c: Context, id: Long) {
        val l = reminders(c); val r = l.find { it.id == id } ?: return
        if (r.repeat == 0) return
        var x = r; val now = System.currentTimeMillis()
        while (x.at <= now + 1000) x = x.copy(at = nextAt(x), done = false)
        saveReminders(c, l.map { if (it.id == id) x else it }); Alarms.set(c, x)
    }
    fun normalize(c: Context) {
        val now = System.currentTimeMillis(); var ch = false
        val l = reminders(c).map { r -> var x = r; while (x.repeat > 0 && x.at < now - 60000) { x = x.copy(at = nextAt(x), done = false); ch = true }; x }
        if (ch) { saveReminders(c, l); l.forEach { Alarms.set(c, it) } }
    }
    fun occurrences(l: List<Reminder>, f: Long, t: Long): List<Occ> {
        val out = mutableListOf<Occ>()
        l.forEach { r -> var x = r; var first = true; var n = 0
            while (x.at < t && n++ < 400) { if (x.at >= f) out.add(Occ(r, x.at, first)); if (x.repeat == 0) break; x = x.copy(at = nextAt(x)); first = false } }
        return out.sortedBy { it.at }
    }
    fun moods(c: Context): Map<Long, List<Int>> {
        val o = JSONObject(p(c).getString("m", "{}"))
        return o.keys().asSequence().associate { k -> val v = o.get(k); k.toLong() to (if (v is JSONArray) List(2) { i -> v.optInt(i, -1) } else listOf(v as Int, -1)) }
    }
    fun putMood(c: Context, day: Long, slot: Int, lv: Int) {
        val m = moods(c)[day]?.toMutableList() ?: mutableListOf(-1, -1); m[slot] = lv
        val o = JSONObject(p(c).getString("m", "{}")); o.put(day.toString(), JSONArray(m)); p(c).edit().putString("m", o.toString()).apply()
    }
    fun addMood(c: Context, day: Long, lv: Int) { val m = moods(c)[day]; putMood(c, day, if (m == null || m[0] == -1) 0 else 1, lv) }
    fun moodTimes(c: Context): List<Int> { val a = JSONArray(p(c).getString("mt", "[]")); return List(a.length()) { a.getInt(it) }.sorted() }
    fun setMoodTimes(c: Context, l: List<Int>) { p(c).edit().putString("mt", JSONArray(l).toString()).apply() }
    fun backup(c: Context): String = JSONObject().put("r", JSONArray(p(c).getString("r", "[]"))).put("m", JSONObject(p(c).getString("m", "{}"))).put("mt", JSONArray(p(c).getString("mt", "[]"))).toString()
    fun restore(c: Context, s: String) {
        val o = JSONObject(s)
        val e = p(c).edit().putString("r", o.getJSONArray("r").toString()).putString("m", o.getJSONObject("m").toString())
        if (o.has("mt")) e.putString("mt", o.getJSONArray("mt").toString())
        e.apply(); normalize(c); reminders(c).forEach { Alarms.set(c, it) }; MoodAlarms.syncAll(c); ReminderWidget.refresh(c)
    }
}
