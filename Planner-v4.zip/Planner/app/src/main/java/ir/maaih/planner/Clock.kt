package ir.maaih.planner
import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.*

class ClockWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = refresh(c)
    override fun onDisabled(c: Context) { c.getSystemService(AlarmManager::class.java).cancel(tickPi(c)) }
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == TICK) { refresh(c); ReminderWidget.refresh(c) } else super.onReceive(c, i)
    }
    private class Ev(val s: Float, val e: Float, val col: Int, val title: String)
    companion object {
        const val TICK = "ir.maaih.planner.TICK"
        private fun tickPi(c: Context) = PendingIntent.getBroadcast(c, 300, Intent(c, ClockWidget::class.java).setAction(TICK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, ClockWidget::class.java)); if (ids.isEmpty()) return
            c.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC, System.currentTimeMillis() + 300000, tickPi(c))
            val rv = RemoteViews(c.packageName, R.layout.widget_clock)
            rv.setImageViewBitmap(R.id.c_img, draw(c, 480))
            rv.setOnClickPendingIntent(R.id.c_img, PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            rv.setOnClickPendingIntent(R.id.c_center, PendingIntent.getActivity(c, 1,
                Intent(c, MainActivity::class.java).putExtra("add", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            ids.forEach { m.updateAppWidget(it, rv) }
        }
        private fun draw(c: Context, sz: Int): Bitmap {
            val bmp = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp)
            val cx = sz / 2f; val R = cx - 4f; val rIn = R * 0.45f; val rOut = R * 0.80f
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = LinearGradient(0f, 0f, sz.toFloat(), sz.toFloat(), 0xFFEFFAA8.toInt(), 0xFFFFFFFF.toInt(), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cx, R, p); p.shader = null
            p.color = 0xB3FFFFFF.toInt(); cv.drawCircle(cx, cx, rOut, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x22000000
            for (h in 0 until 24) { val a = Math.toRadians(h * 15.0)
                cv.drawLine(cx + (rIn * sin(a)).toFloat(), cx - (rIn * cos(a)).toFloat(), cx + (rOut * sin(a)).toFloat(), cx - (rOut * cos(a)).toFloat(), p) }
            p.style = Paint.Style.FILL
            val today = LocalDate.now(); val f = today.ms(); val t = today.plusDays(1).ms()
            val evs = Store.occurrences(Store.reminders(c), f - 86400000L, t).filter { it.r.trig == 0 && !(it.first && it.r.done) }.mapNotNull { o ->
                val s = maxOf(o.at, f); val e = minOf(o.at + o.r.dur * 60000L, t)
                if (e <= s) null else Ev((s - f) / 60000f, (e - f) / 60000f, o.r.col, o.r.title) }.sortedBy { it.s }
            val laneEnd = FloatArray(3); val lane = IntArray(evs.size)
            evs.forEachIndexed { i, e -> var k = 0; while (k < 2 && laneEnd[k] > e.s) k++; lane[i] = k; laneEnd[k] = max(laneEnd[k], e.e) }
            val lanes = (lane.maxOrNull() ?: 0) + 1; val th = (rOut - rIn) / lanes
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF111111.toInt(); typeface = Typeface.DEFAULT_BOLD }
            evs.forEachIndexed { i, e ->
                val r0 = rIn + lane[i] * th; val r1 = r0 + th
                val a0 = e.s / 1440f * 360f - 90f; val sw = (e.e - e.s) / 1440f * 360f
                val path = Path(); path.arcTo(RectF(cx - r1, cx - r1, cx + r1, cx + r1), a0, sw); path.arcTo(RectF(cx - r0, cx - r0, cx + r0, cx + r0), a0 + sw, -sw); path.close()
                p.color = Palette[e.col.coerceIn(0, 9)].toInt(); cv.drawPath(path, p)
                val ts = min(th * 0.5f, R * 0.09f); val rm = (r0 + r1) / 2f
                val arcLen = (Math.toRadians(sw.toDouble()) * rm).toFloat() - 8f
                if (ts >= 13f && arcLen > 20f) {
                    tp.textSize = ts; var txt = e.title
                    val n = tp.breakText(txt, true, arcLen, null); if (n < txt.length) txt = txt.substring(0, max(1, n - 1)) + "…"
                    val w = tp.measureText(txt); val rect = RectF(cx - rm, cx - rm, cx + rm, cx + rm); val arc = Path()
                    val mid = (e.s + e.e) / 2f / 1440f * 360f
                    if (mid in 90f..270f) arc.arcTo(rect, a0 + sw, -sw, true) else arc.arcTo(rect, a0, sw, true)
                    cv.drawTextOnPath(txt, arc, (arcLen + 8f - w) / 2f, ts * 0.35f, tp)
                }
            }
            val np = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF333333.toInt(); textAlign = Paint.Align.CENTER; textSize = R * 0.085f }
            for (h in 0 until 24) { val a = Math.toRadians(h * 15.0); val rr = R * 0.905f
                cv.drawText(Jalali.fa(h), cx + (rr * sin(a)).toFloat(), cx - (rr * cos(a)).toFloat() + np.textSize * 0.35f, np) }
            val now = LocalTime.now(); val ha = Math.toRadians((now.hour * 60 + now.minute) / 1440.0 * 360.0)
            p.style = Paint.Style.STROKE; p.strokeWidth = R * 0.035f; p.strokeCap = Paint.Cap.ROUND; p.color = 0xFFE53935.toInt()
            cv.drawLine(cx + (rIn * 0.98 * sin(ha)).toFloat(), cx - (rIn * 0.98 * cos(ha)).toFloat(), cx + (R * 0.86 * sin(ha)).toFloat(), cx - (R * 0.86 * cos(ha)).toFloat(), p)
            p.style = Paint.Style.FILL; p.color = Color.WHITE; cv.drawCircle(cx, cx, rIn - 3f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = 0x22000000; cv.drawCircle(cx, cx, rIn - 3f, p)
            val j = Jalali.of(today)
            val cp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = 0xFF111111.toInt(); typeface = Typeface.DEFAULT_BOLD }
            cp.color = 0xFF777777.toInt(); cp.textSize = R * 0.075f; cv.drawText("SMA", cx, cx - rIn * 0.52f, cp)
            cp.color = 0xFF111111.toInt(); cp.textSize = R * 0.085f; cv.drawText(Jalali.dayName(today), cx, cx - rIn * 0.18f, cp)
            cp.textSize = R * 0.17f; cv.drawText(Jalali.fa("%02d:%02d".format(now.hour, now.minute)), cx, cx + rIn * 0.30f, cp)
            cp.typeface = Typeface.DEFAULT; cp.textSize = R * 0.075f; cv.drawText(Jalali.fa("${j.third} ${Jalali.months[j.second - 1]} ${j.first}"), cx, cx + rIn * 0.68f, cp)
            return bmp
        }
    }
}
