package ir.maaih.planner
import android.content.Context
import android.graphics.*
import android.text.*

object Card {
    private fun lay(t: String, p: TextPaint, w: Int, lines: Int) = StaticLayout.Builder.obtain(t, 0, t.length, p, w)
        .setMaxLines(lines).setEllipsize(TextUtils.TruncateAt.END).setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
        .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
    fun bitmap(c: Context, title: String, body: String): Bitmap {
        val homa = c.resources.getFont(R.font.homa)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = homa; textSize = 52f; color = 0xFF111111.toInt(); isFakeBoldText = true }
        val bp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = homa; textSize = 40f; color = 0xFF444444.toInt() }
        val w = 1000; val pad = 46; val badge = 84; val gap = 26; val tw = w - 2 * pad - badge - gap
        val tl = lay(title, tp, tw, 2); val bl = if (body.isBlank()) null else lay(body, bp, tw, 3)
        val th = tl.height + (if (bl != null) bl.height + 10 else 0)
        val h = pad * 2 + maxOf(badge, th)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFFEFFAA8.toInt(), 0xFFFFFFFF.toInt(), Shader.TileMode.CLAMP)
        cv.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), 56f, 56f, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = 0x22000000; cv.drawRoundRect(RectF(1.5f, 1.5f, w - 1.5f, h - 1.5f), 56f, 56f, p)
        val bx = w - pad - badge / 2f; val by = pad + badge / 2f
        p.style = Paint.Style.FILL; p.shader = LinearGradient(bx - 42, by - 42, bx + 42, by + 42, 0xFFD7F14F.toInt(), 0xFF7BE08A.toInt(), Shader.TileMode.CLAMP)
        cv.drawCircle(bx, by, badge / 2f, p); p.shader = null
        val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = 46f; color = 0xFF111111.toInt() }
        cv.drawText("✦", bx, by + 16f, sp)
        cv.save(); cv.translate(pad.toFloat(), pad.toFloat()); tl.draw(cv)
        if (bl != null) { cv.translate(0f, tl.height + 10f); bl.draw(cv) }
        cv.restore()
        return bmp
    }
}
