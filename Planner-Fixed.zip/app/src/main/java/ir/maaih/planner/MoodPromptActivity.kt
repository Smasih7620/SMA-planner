package ir.maaih.planner
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.time.LocalDate

class MoodPromptActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        setContent { AppTheme {
            Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                GradCard(Modifier.padding(20.dp).fillMaxWidth()) {
                    Title("الان حالت چطوره؟"); Spacer(Modifier.height(16.dp))
                    Faces(null) { lv ->
                        Store.addMood(this@MoodPromptActivity, LocalDate.now().toEpochDay(), lv)
                        getSystemService(NotificationManager::class.java).cancel(777)
                        Toast.makeText(this@MoodPromptActivity, "ثبت شد ✅", Toast.LENGTH_SHORT).show(); finish()
                    }
                    TextButton({ finish() }, Modifier.align(Alignment.CenterHorizontally)) { Text("بعداً", color = Ink) }
                }
            }
        } }
    }
}
