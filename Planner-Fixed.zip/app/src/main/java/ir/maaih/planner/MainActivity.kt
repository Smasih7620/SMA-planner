@file:OptIn(ExperimentalMaterial3Api::class)
package ir.maaih.planner
import android.Manifest
import android.annotation.SuppressLint
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.*
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import java.time.*

val Lime = Color(0xFFEFFAA8)
val Ink = Color(0xFF111111)

val Titr = FontFamily(Font(R.font.titr))
val Homa = FontFamily(Font(R.font.homa))
private fun Typography.homa() = copy(
    displayLarge = displayLarge.copy(fontFamily = Homa), displayMedium = displayMedium.copy(fontFamily = Homa), displaySmall = displaySmall.copy(fontFamily = Homa),
    headlineLarge = headlineLarge.copy(fontFamily = Homa), headlineMedium = headlineMedium.copy(fontFamily = Homa), headlineSmall = headlineSmall.copy(fontFamily = Homa),
    titleLarge = titleLarge.copy(fontFamily = Homa), titleMedium = titleMedium.copy(fontFamily = Homa), titleSmall = titleSmall.copy(fontFamily = Homa),
    bodyLarge = bodyLarge.copy(fontFamily = Homa), bodyMedium = bodyMedium.copy(fontFamily = Homa), bodySmall = bodySmall.copy(fontFamily = Homa),
    labelLarge = labelLarge.copy(fontFamily = Homa), labelMedium = labelMedium.copy(fontFamily = Homa), labelSmall = labelSmall.copy(fontFamily = Homa))

@Composable fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Ink, onPrimary = Color.White, primaryContainer = Lime, onPrimaryContainer = Ink,
        secondaryContainer = Lime, onSecondaryContainer = Ink, background = Color(0xFFF4F7EA), surface = Color(0xFFF4F7EA), surfaceVariant = Color(0xFFE6EDCB)),
        typography = Typography().homa()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { ProvideTextStyle(LocalTextStyle.current.copy(fontFamily = Homa)) { content() } }
    }
}
@Composable fun GradCard(mod: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
    Column(mod.clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Lime, Color.White))).padding(16.dp), content = content)
@Composable fun StarBadge() = Box(Modifier.size(34.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFFD7F14F), Color(0xFF7BE08A)))), contentAlignment = Alignment.Center) { Text("✦", fontSize = 18.sp) }
@Composable fun Title(t: String) = Row(verticalAlignment = Alignment.CenterVertically) { StarBadge(); Spacer(Modifier.width(10.dp)); Text(t, style = MaterialTheme.typography.titleMedium, fontFamily = Titr) }

val moodEmoji = listOf("😭", "😞", "😐", "🙂", "🤩")
val moodName = listOf("خیلی بد", "بد", "نرمال", "خوب", "عالی")
val moodColor = listOf(Color(0xFF7CC8FF), Color(0xFFFF9E80), Color(0xFFFFE23D), Color(0xFFB5E86B), Color(0xFF5CE08A))
@Composable fun Faces(sel: Int?, onPick: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        moodEmoji.forEachIndexed { i, e ->
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onPick(i) }) {
                Box(Modifier.size(52.dp).clip(CircleShape).background(moodColor[i]).then(if (sel == i) Modifier.border(3.dp, Ink, CircleShape) else Modifier), contentAlignment = Alignment.Center) { Text(e, fontSize = 26.sp) }
                Text(moodName[i], fontSize = 11.sp); Text(Jalali.fa("${i * 25}٪"), fontSize = 10.sp)
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    companion object { val addTick = mutableStateOf(0) }
    private var webView: WebView? = null

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("add", false)) {
            addTick.value++
            webView?.loadUrl("javascript:window.dispatchEvent(new CustomEvent('sma_open_add'));")
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Notifs.channels(this); Store.normalize(this); MoodAlarms.syncAll(this); Geo.syncAll(this); AutoBackup.schedule(this); DateNotification.post(this)
        if (intent?.getBooleanExtra("add", false) == true) addTick.value++
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        try {
            val wv = WebView(this).apply {
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.allowFileAccess = true
                settings.allowContentAccess = true
                settings.allowFileAccessFromFileURLs = true
                settings.allowUniversalAccessFromFileURLs = true
                settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                settings.setSupportZoom(false)
                settings.cacheMode = WebSettings.LOAD_DEFAULT

                webViewClient = object : WebViewClient() {
                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                        super.onReceivedError(view, request, error)
                        android.util.Log.e("SMA_PLANNER", "WebView Error: ${error?.description}")
                    }
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val url = request?.url?.toString() ?: ""
                        if (url.startsWith("mailto:") || url.startsWith("tel:") || url.startsWith("geo:")) {
                            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
                            return true
                        }
                        return false
                    }
                }
                webChromeClient = object : WebChromeClient() {
                    override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                        android.util.Log.d("SMA_JS", "${consoleMessage?.message()} (${consoleMessage?.sourceId()}:${consoleMessage?.lineNumber()})")
                        return true
                    }
                    override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                        callback?.invoke(origin, true, false)
                    }
                }

                // Standard Android file asset loading
                loadUrl("file:///android_asset/dist/index.html")
            }
            webView = wv
            setContentView(wv)

            onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (wv.canGoBack()) {
                        wv.goBack()
                    } else {
                        finish()
                    }
                }
            })
        } catch (e: Exception) {
            setContent { AppTheme { App() } }
        }
    }

    override fun onResume() {
        super.onResume()
        DateNotification.post(this)
    }
}

@Composable fun App() {
    var tab by remember { mutableStateOf(0) }
    val tick by MainActivity.addTick
    LaunchedEffect(tick) { if (tick > 0) tab = 0 }
    Scaffold(containerColor = MaterialTheme.colorScheme.background, bottomBar = { NavigationBar(containerColor = Color.White) {
        NavigationBarItem(tab == 0, { tab = 0 }, { Text("📅", fontSize = 20.sp) }, label = { Text("برنامه") })
        NavigationBarItem(tab == 1, { tab = 1 }, { Text("😊", fontSize = 20.sp) }, label = { Text("حال و هوا") })
        NavigationBarItem(tab == 2, { tab = 2 }, { Text("📍", fontSize = 20.sp) }, label = { Text("مکان‌ها") })
        NavigationBarItem(tab == 3, { tab = 3 }, { Text("⚙️", fontSize = 20.sp) }, label = { Text("تنظیمات") })
    } }) { pad -> Box(Modifier.padding(pad)) { when (tab) { 0 -> PlanScreen(tick); 1 -> MoodScreen(); 2 -> PlacesScreen(); else -> SettingsScreen() } } }
}

@Composable fun PlanScreen(openAdd: Int = 0) {
    val c = LocalContext.current
    var list by remember { mutableStateOf(Store.reminders(c)) }
    var mode by remember { mutableStateOf(0) }; var off by remember { mutableStateOf(0) }
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(openAdd) { if (openAdd > 0) show = true }
    var editing by remember { mutableStateOf<Reminder?>(null) }
    val bgL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { Geo.syncAll(c) }
    fun save(l: List<Reminder>) { list = l.sortedBy { it.at }; Store.saveReminders(c, list) }
    val (from, to) = rangeOf(mode, off)
    val shown = Store.occurrences(list, from.ms(), to.ms())
    val rep = listOf("", "  🔁 روزانه", "  🔁 هفتگی", "  🔁 ماهانه")
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StarBadge(); Spacer(Modifier.width(10.dp))
                Text(Jalali.label(mode, from, to), style = MaterialTheme.typography.titleLarge, fontFamily = Titr, modifier = Modifier.weight(1f))
                TextButton({ off-- }) { Text("›", fontSize = 24.sp, color = Ink) }; TextButton({ off++ }) { Text("‹", fontSize = 24.sp, color = Ink) }
            }
            Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("امروز", "این هفته", "این ماه").forEachIndexed { i, s -> FilterChip(mode == i, { mode = i; off = 0 }, { Text(s) }) }
            }
            if (shown.isEmpty()) Text("یادآوری‌ای ثبت نشده ✨", Modifier.padding(top = 24.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                items(shown, key = { "${it.r.id}_${it.at}" }) { o ->
                    val r = o.r; val done = o.first && r.done
                    GradCard(Modifier.fillMaxWidth().alpha(if (done) 0.4f else 1f).clickable { editing = r }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(done, { d -> Store.setDone(c, r.id, d); list = Store.reminders(c) },
                                enabled = o.first, colors = CheckboxDefaults.colors(checkedColor = Ink))
                            Box(Modifier.size(12.dp).clip(CircleShape).background(Color(Palette[r.col])))
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(r.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, textDecoration = if (done) TextDecoration.LineThrough else null)
                                Text(Jalali.fmt(o.at) + " تا " + Jalali.time(o.at + r.dur * 60000L) + rep[r.repeat], fontSize = 12.sp)
                            }
                            TextButton({ Alarms.cancel(c, r); save(list.filter { it.id != r.id }) }) { Text("🗑") }
                        }
                    }
                }
            }
        }
        FloatingActionButton({ show = true }, Modifier.align(Alignment.BottomStart).padding(16.dp), containerColor = Ink, contentColor = Color.White) { Text("＋", fontSize = 24.sp) }
    }
    if (show || editing != null) AddDialog(editing, 0, { show = false; editing = null }) { r ->
        val old = editing
        if (old != null) { Alarms.cancel(c, old); Geo.remove(c, old) }
        Alarms.set(c, r); Geo.add(c, r)
        save(list.filter { it.id != r.id } + r); show = false; editing = null
        if (r.trig > 0 && Build.VERSION.SDK_INT >= 29 && c.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(c, "در صفحه بعد «Allow all the time» (همیشه مجاز) رو انتخاب کن", Toast.LENGTH_LONG).show()
            bgL.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        }
    }
}

@Composable fun RowScope.Num(v: String, label: String, set: (String) -> Unit) =
    OutlinedTextField(v, set, Modifier.weight(1f), label = { Text(label) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))

@Composable fun AddDialog(initial: Reminder? = null, startType: Int = 0, onDismiss: () -> Unit, onSave: (Reminder) -> Unit) {
    val c = LocalContext.current
    val now = LocalDateTime.now()
    val base = if (initial != null && initial.trig == 0) LocalDateTime.ofInstant(Instant.ofEpochMilli(initial.at), ZoneId.systemDefault()) else now
    val j = Jalali.of(base.toLocalDate()); val endT = base.plusMinutes((initial?.dur ?: 60).toLong())
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var y by remember { mutableStateOf(j.first.toString()) }; var m by remember { mutableStateOf(j.second.toString()) }; var d by remember { mutableStateOf(j.third.toString()) }
    var h by remember { mutableStateOf(base.hour.toString()) }; var mi by remember { mutableStateOf(if (initial != null) base.minute.toString() else "0") }
    var col by remember { mutableStateOf(initial?.col ?: 3) }; var hasEnd by remember { mutableStateOf(initial != null && initial.trig == 0 && initial.dur != 60) }
    var eh by remember { mutableStateOf(if (initial != null) endT.hour.toString() else ((now.hour + 1) % 24).toString()) }; var emi by remember { mutableStateOf(if (initial != null) endT.minute.toString() else "0") }
    var rep by remember { mutableStateOf(initial?.repeat ?: 0) }; var err by remember { mutableStateOf(false) }
    var type by remember { mutableStateOf(if (initial != null) (if (initial.trig > 0) 1 else 0) else startType) }
    var lat by remember { mutableStateOf<Double?>(if (initial != null && initial.trig > 0) initial.lat else null) }
    var lng by remember { mutableStateOf<Double?>(if (initial != null && initial.trig > 0) initial.lng else null) }
    var rad by remember { mutableStateOf(if (initial != null && initial.rad > 0) initial.rad.toFloat() else 50f) }
    var trig by remember { mutableStateOf(if (initial != null && initial.trig > 0) initial.trig else 1) }
    var showMap by remember { mutableStateOf(false) }
    val fg = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r -> if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) showMap = true }
    val wd = try { Jalali.dayName(Jalali.toDate(Jalali.en(y).toInt(), Jalali.en(m).toInt(), Jalali.en(d).toInt())) } catch (e: Exception) { "—" }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Color.White, title = { Title(if (initial == null) "یادآوری جدید" else "ویرایش یادآوری") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("مثلاً: قرار با ستاره") })
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("⏰ زمانی", "📍 مکانی").forEachIndexed { i, s -> FilterChip(type == i, { type = i }, { Text(s) }) } }
            if (type == 1) {
                OutlinedButton({ if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) showMap = true else fg.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }, Modifier.fillMaxWidth()) {
                    Text(if (lat == null) "🗺️ انتخاب مکان روی نقشه" else "✅ مکان انتخاب شد (تغییر)", color = Ink) }
                Text(Jalali.fa("شعاع: ${rad.roundToInt()} متر"))
                Slider(rad, { rad = it }, valueRange = 10f..100f, steps = 8, colors = SliderDefaults.colors(thumbColor = Ink, activeTrackColor = Ink))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { FilterChip(trig == 1, { trig = 1 }, { Text("وقتی رسیدم", fontSize = 12.sp) }); FilterChip(trig == 2, { trig = 2 }, { Text("وقتی خارج شدم", fontSize = 12.sp) }) }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Num(y, "سال") { y = it }; Num(m, "ماه") { m = it }; Num(d, "روز") { d = it } }
                Text("📅 روز هفته: $wd", fontWeight = FontWeight.Bold)
                Text("زمان شروع", fontSize = 12.sp)
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Num(h, "ساعت") { h = it }; Text(":", fontSize = 22.sp); Num(mi, "دقیقه") { mi = it }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(hasEnd, { hasEnd = it }, colors = CheckboxDefaults.colors(checkedColor = Ink)); Text("زمان پایان (اختیاری، پیش‌فرض ۱ ساعت)", fontSize = 12.sp) }
                if (hasEnd) CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) { Num(eh, "ساعت") { eh = it }; Text(":", fontSize = 22.sp); Num(emi, "دقیقه") { emi = it } }
                }
                Text("رنگ یادآوری", fontSize = 12.sp)
                (0..1).forEach { rw -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { (0..4).forEach { k -> val i = rw * 5 + k
                    Box(Modifier.size(34.dp).clip(CircleShape).background(Color(Palette[i])).then(if (col == i) Modifier.border(3.dp, Ink, CircleShape) else Modifier).clickable { col = i }) } } }
                Text("تکرار", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("یک‌بار", "روزانه", "هفتگی", "ماهانه").forEachIndexed { i, s -> FilterChip(rep == i, { rep = i }, { Text(s, fontSize = 12.sp) }) } }
            }
            if (err) Text(if (type == 1) "اول مکان رو روی نقشه انتخاب کن" else "تاریخ یا ساعت نامعتبر است", color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { TextButton({
        try {
            require(title.isNotBlank())
            val id = initial?.id ?: System.currentTimeMillis()
            if (type == 1) {
                val la = lat; val lo = lng
                if (la == null || lo == null) throw Exception("no place")
                onSave(Reminder(id, title.trim(), 0, false, 0, la, lo, rad.roundToInt(), trig))
            } else {
                val yy = Jalali.en(y).toInt(); val mm = Jalali.en(m).toInt(); val dd = Jalali.en(d).toInt()
                require(mm in 1..12 && dd in 1..Jalali.monthLen(yy, mm))
                val at = LocalDateTime.of(Jalali.toDate(yy, mm, dd), LocalTime.of(Jalali.en(h).toInt(), Jalali.en(mi).toInt())).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                var dur = 60
                if (hasEnd) { var d2 = (Jalali.en(eh).toInt() * 60 + Jalali.en(emi).toInt()) - (Jalali.en(h).toInt() * 60 + Jalali.en(mi).toInt()); if (d2 <= 0) d2 += 1440; dur = d2 }
                onSave(Reminder(id, title.trim(), at, false, rep, col = col, dur = dur))
            }
        } catch (e: Exception) { err = true }
    }) { Text("ذخیره", color = Ink) } }, dismissButton = { TextButton(onDismiss) { Text("انصراف", color = Ink) } })
    if (showMap) MapPicker(lat ?: 35.6892, lng ?: 51.3890, { la, lo -> lat = la; lng = lo; showMap = false }, { showMap = false })
}

@Composable fun MoodScreen() {
    val c = LocalContext.current
    var moods by remember { mutableStateOf(Store.moods(c)) }
    val today = LocalDate.now(); val td = today.toEpochDay()
    fun avg(n: Int): Int? { val v = (0 until n).flatMap { moods[td - it]?.filter { x -> x >= 0 } ?: emptyList() }; return if (v.isEmpty()) null else v.sum() * 25 / v.size }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GradCard(Modifier.fillMaxWidth()) {
            Title("حالت امروز چطوره؟ (${Jalali.dayName(today)})")
            listOf("نوبت اول", "نوبت دوم").forEachIndexed { slot, name ->
                Text(name, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
                Faces(moods[td]?.get(slot)?.takeIf { it >= 0 }) { lv -> Store.putMood(c, td, slot, lv); moods = Store.moods(c) }
            }
        }
        GradCard(Modifier.fillMaxWidth()) {
            Title("میانگین حال و هوا")
            listOf("روزانه" to 1, "هفتگی (۷ روز اخیر)" to 7, "ماهانه (۳۰ روز اخیر)" to 30, "سالانه (۳۶۵ روز اخیر)" to 365).forEach { (name, n) ->
                val a = avg(n)
                Text(if (a == null) "$name: —" else Jalali.fa("$name: $a٪ ${moodEmoji[((a + 12) / 25).coerceIn(0, 4)]}"), Modifier.padding(top = 10.dp))
                LinearProgressIndicator(progress = { (a ?: 0) / 100f }, Modifier.fillMaxWidth().padding(top = 4.dp), color = Ink, trackColor = Color.White)
            }
        }
        GradCard(Modifier.fillMaxWidth()) {
            Title("۷ روز اخیر")
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                (6 downTo 0).forEach { k ->
                    val v = moods[td - k]?.filter { it >= 0 } ?: emptyList()
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (v.isEmpty()) "·" else v.joinToString("") { moodEmoji[it] }, fontSize = 16.sp)
                        Text(Jalali.fa(Jalali.of(today.minusDays(k.toLong())).third), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable fun SettingsScreen() {
    val c = LocalContext.current
    var times by remember { mutableStateOf(Store.moodTimes(c)) }
    fun msg(t: String) = Toast.makeText(c, t, Toast.LENGTH_LONG).show()
    val out = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) try { c.contentResolver.openOutputStream(u)!!.use { it.write(Store.backup(c).toByteArray()) }; msg("پشتیبان ذخیره شد ✅") } catch (e: Exception) { msg("خطا در ذخیره فایل") }
    }
    val inp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) try { Store.restore(c, c.contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }); times = Store.moodTimes(c); msg("اطلاعات بازیابی شد ✅") } catch (e: Exception) { msg("فایل نامعتبر است") }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GradCard(Modifier.fillMaxWidth()) {
            Title("ساعت‌های پرسیدن حال و هوا")
            Text("در این ساعت‌ها هر روز یه پنجره میاد و می‌پرسه الان حالت چطوره.", fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            times.forEach { m -> Row(verticalAlignment = Alignment.CenterVertically) {
                Text("⏰ " + Jalali.fa("%02d:%02d".format(m / 60, m % 60)), Modifier.weight(1f))
                TextButton({ MoodAlarms.cancel(c, m); times = times - m; Store.setMoodTimes(c, times) }) { Text("🗑") }
            } }
            Button({ TimePickerDialog(c, { _, hh, mm -> val t = hh * 60 + mm; if (t !in times) { times = (times + t).sorted(); Store.setMoodTimes(c, times); MoodAlarms.set(c, t) } }, 12, 0, true).show() },
                colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text("＋ افزودن ساعت") }
        }
        GradCard(Modifier.fillMaxWidth()) {
            Title("صدای اعلان‌ها")
            Text("هر کدوم رو جدا باز کن و توی تنظیمات گوشی «Sound» رو بزن تا آهنگ دلخواه رو انتخاب کنی.", fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            OutlinedButton({ Notifs.openChannel(c, "rem") }, Modifier.fillMaxWidth()) { Text("🎵 صدای یادآوری‌ها", color = Ink) }
            OutlinedButton({ Notifs.openChannel(c, "mood") }, Modifier.fillMaxWidth()) { Text("🎵 صدای حال و هوا", color = Ink) }
        }
        GradCard(Modifier.fillMaxWidth()) {
            Title("پشتیبان‌گیری")
            Text("فایل پشتیبان رو توی Google Drive یا تلگرام نگه دار و روی گوشی جدید بازیابی کن.", fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            Button({ out.launch("planner-backup.json") }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text("📤 ذخیره فایل پشتیبان") }
            OutlinedButton({ inp.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("📥 بازیابی از فایل پشتیبان", color = Ink) }
        }
        AutoBackupCard()
        GradCard(Modifier.fillMaxWidth()) {
            Title("درباره برنامه")
            Text("ورژن ۱.۱", Modifier.padding(top = 10.dp))
            Text("ساخته شده توسط: مجتبی زارعی SMA", Modifier.padding(top = 4.dp))
            Text("Smasih7620@gmail.com", Modifier.padding(top = 4.dp).clickable { try { c.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:Smasih7620@gmail.com"))) } catch (e: Exception) { msg("برنامه ایمیل پیدا نشد") } }, textDecoration = TextDecoration.Underline)
        }
    }
}

@Composable fun PlacesScreen() {
    val c = LocalContext.current
    var list by remember { mutableStateOf(Store.reminders(c).filter { it.trig > 0 }) }
    var editing by remember { mutableStateOf<Reminder?>(null) }; var adding by remember { mutableStateOf(false) }
    fun reload() { list = Store.reminders(c).filter { it.trig > 0 } }
    val bgL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { Geo.syncAll(c) }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Title("یادآوری‌های مکانی"); Spacer(Modifier.height(10.dp))
            if (list.isEmpty()) Text("هنوز یادآوری مکانی نداری. با «＋» یکی بساز 📍")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                items(list, key = { it.id }) { r ->
                    GradCard(Modifier.fillMaxWidth().alpha(if (r.done) 0.4f else 1f).clickable { editing = r }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(r.done, { d -> Store.setDone(c, r.id, d); reload() }, colors = CheckboxDefaults.colors(checkedColor = Ink))
                            Column(Modifier.weight(1f)) {
                                Text("📍 " + r.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, textDecoration = if (r.done) TextDecoration.LineThrough else null)
                                Text(Jalali.fa("شعاع ${r.rad} متر") + (if (r.trig == 1) " · وقتی رسیدم" else " · وقتی خارج شدم") + (if (!r.armed) (if (r.again) " · بعد از رفت‌وآمد دوباره فعال می‌شه" else " · اعلان داده شد") else ""), fontSize = 12.sp)
                                Text(String.format(java.util.Locale.US, "%.5f, %.5f", r.lat, r.lng), fontSize = 10.sp)
                            }
                            TextButton({ Geo.remove(c, r); Store.saveReminders(c, Store.reminders(c).filter { it.id != r.id }); reload() }) { Text("🗑") }
                        }
                    }
                }
            }
        }
        FloatingActionButton({ adding = true }, Modifier.align(Alignment.BottomStart).padding(16.dp), containerColor = Ink, contentColor = Color.White) { Text("＋", fontSize = 24.sp) }
    }
    if (adding || editing != null) AddDialog(editing, 1, { adding = false; editing = null }) { r ->
        val old = editing
        if (old != null) { Alarms.cancel(c, old); Geo.remove(c, old) }
        Alarms.set(c, r); Geo.add(c, r)
        Store.saveReminders(c, Store.reminders(c).filter { it.id != r.id } + r); adding = false; editing = null; reload()
        if (r.trig > 0 && Build.VERSION.SDK_INT >= 29 && c.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(c, "در صفحه بعد «Allow all the time» (همیشه مجاز) رو انتخاب کن", Toast.LENGTH_LONG).show()
            bgL.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        }
    }
}
