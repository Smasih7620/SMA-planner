# Planner (روز من) - Android Application

پروژه اندرویدی برنامه‌ریزی روزانه، تقویم جلالی، یادآور و ویجت‌های هوشمند.

## 📱 ساخت خودکار فایل APK با GitHub Actions

این مخزن به گونه‌ای پیکربندی شده است که با هر بار Push، فایل‌های APK دیباگ و ریلیز به‌طور خودکار ساخته می‌شوند:

1. به تب **Actions** در بالای صفحه مخزن بروید.
2. روی آخرین اجرای **Build Android APK** کلیک کنید.
3. در انتهای صفحه در بخش **Artifacts**، فایل **Planner-APK** را دانلود کنید.

## 🛠 مشخصات فنی
- **Namespace:** `ir.maaih.planner`
- **Gradle:** 8.7
- **AGP:** 8.5.2
- **Kotlin:** 1.9.24
- **Jetpack Compose:** Compose BOM 2024.09.00
- **Target SDK:** 34 (Android 14)
- **Min SDK:** 26 (Android 8.0)
