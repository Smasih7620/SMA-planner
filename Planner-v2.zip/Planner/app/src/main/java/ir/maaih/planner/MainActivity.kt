@file:OptIn(ExperimentalMaterial3Api::class)
package ir.maaih.planner
import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.*

val Lime = Color(0xFFEFFAA8)
val Ink = Color(0xFF111111)

@Composable fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Ink, onPrimary = Color.White, primaryContainer = Lime, onPrimaryContainer = Ink,
        secondaryContainer = Lime, onSecondaryContainer = Ink, background = Color(0xFFF4F7EA), surface = Color(0xFFF4F7EA), surfaceVariant = Color(0xFFE6EDCB))) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { content() }
    }
}
@Composable fun GradCard(mod: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
    Column(mod.clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Lime, Color.White))).padding(16.dp), content = content)
@Composable fun StarBadge() = Box(Modifier.size(34.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFFD7F14F), Color(0xFF7BE08A)))), contentAlignment = Alignment.Center) { Text("✦", fontSize = 18.sp) }
@Composable fun Title(t: String) = Row(verticalAlignment = Alignment.CenterVertically) { StarBadge(); Spacer(Modifier.width(10.dp)); Text(t, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }

val moodEmoji = listOf("😭", "😞", "😐", "🙂", "🤩")
val moodName = listOf("خیلی بد", "بد", "نرمال", "خوب", "عالی")
val moodColor = listOf(Color(0xFF7CC8FF), Color(0xFFFF9E80), Color(0xFFFFE23D), Color(0xFFB5E86B), Color(0xFF5CE08A))
@Composable fun Faces(sel: Int?, onPick: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        moodEmoji.forEachIndexed { i, e ->
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onPick(i) }) {
                Box(Modifier.size(52.dp).clip(CircleShape).background(moodColor[i]).then(if (sel == i) Modifier.border(3.dp, Ink, CircleShape) else Modifier), contentAlignment = Alignment.Center) { Text(e, fontSize = 26.sp) }
                Text(moodName[i], fontSize = 11.sp); Text(Jalali.fa("${i * 25}٪"), fontSize = 10.sp)
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Notifs.channels(this); Store.normalize(this); MoodAlarms.syncAll(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { AppTheme { App() } }
    }
}

@Composable fun App() {
    var tab by remember { mutableStateOf(0) }
    Scaffold(containerColor = MaterialTheme.colorScheme.background, bottomBar = { NavigationBar(containerColor = Color.White) {
        NavigationBarItem(tab == 0, { tab = 0 }, { Text("📅", fontSize = 20.sp) }, label = { Text("برنامه") })
        NavigationBarItem(tab == 1, { tab = 1 }, { Text("😊", fontSize = 20.sp) }, label = { Text("حال و هوا") })
        NavigationBarItem(tab == 2, { tab = 2 }, { Text("⚙️", fontSize = 20.sp) }, label = { Text("تنظیمات") })
    } }) { pad -> Box(Modifier.padding(pad)) { when (tab) { 0 -> PlanScreen(); 1 -> MoodScreen(); else -> SettingsScreen() } } }
}

@Composable fun PlanScreen() {
    val c = LocalContext.current
    var list by remember { mutableStateOf(Store.reminders(c)) }
    var mode by remember { mutableStateOf(0) }; var off by remember { mutableStateOf(0) }
    var show by remember { mutableStateOf(false) }
    fun save(l: List<Reminder>) { list = l.sortedBy { it.at }; Store.saveReminders(c, list) }
    val (from, to) = rangeOf(mode, off)
    val shown = Store.occurrences(list, from.ms(), to.ms())
    val rep = listOf("", "  🔁 روزانه", "  🔁 هفتگی", "  🔁 ماهانه")
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StarBadge(); Spacer(Modifier.width(10.dp))
                Text(Jalali.label(mode, from, to), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton({ off-- }) { Text("›", fontSize = 24.sp, color = Ink) }; TextButton({ off++ }) { Text("‹", fontSize = 24.sp, color = Ink) }
            }
            Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("امروز", "این هفته", "این ماه").forEachIndexed { i, s -> FilterChip(mode == i, { mode = i; off = 0 }, { Text(s) }) }
            }
            if (shown.isEmpty()) Text("یادآوری‌ای ثبت نشده ✨", Modifier.padding(top = 24.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                items(shown, key = { "${it.r.id}_${it.at}" }) { o ->
                    val r = o.r; val done = o.first && r.done
                    GradCard(Modifier.fillMaxWidth().alpha(if (done) 0.4f else 1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(done, { d -> val n = r.copy(done = d); if (d && r.repeat == 0) Alarms.cancel(c, r) else Alarms.set(c, n); save(list.map { if (it.id == r.id) n else it }) },
                                enabled = o.first, colors = CheckboxDefaults.colors(checkedColor = Ink))
                            Column(Modifier.weight(1f)) {
                                Text(r.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, textDecoration = if (done) TextDecoration.LineThrough else null)
                                Text(Jalali.fmt(o.at) + rep[r.repeat], fontSize = 12.sp)
                            }
                            TextButton({ Alarms.cancel(c, r); save(list.filter { it.id != r.id }) }) { Text("🗑") }
                        }
                    }
                }
            }
        }
        FloatingActionButton({ show = true }, Modifier.align(Alignment.BottomStart).padding(16.dp), containerColor = Ink, contentColor = Color.White) { Text("＋", fontSize = 24.sp) }
    }
    if (show) AddDialog({ show = false }) { r -> Alarms.set(c, r); save(list + r); show = false }
}

@Composable fun RowScope.Num(v: String, label: String, set: (String) -> Unit) =
    OutlinedTextField(v, set, Modifier.weight(1f), label = { Text(label) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))

@Composable fun AddDialog(onDismiss: () -> Unit, onSave: (Reminder) -> Unit) {
    val now = LocalDateTime.now(); val j = Jalali.of(now.toLocalDate())
    var title by remember { mutableStateOf("") }
    var y by remember { mutableStateOf(j.first.toString()) }; var m by remember { mutableStateOf(j.second.toString()) }; var d by remember { mutableStateOf(j.third.toString()) }
    var h by remember { mutableStateOf(now.hour.toString()) }; var mi by remember { mutableStateOf("0") }
    var rep by remember { mutableStateOf(0) }; var err by remember { mutableStateOf(false) }
    val wd = try { Jalali.dayName(Jalali.toDate(Jalali.en(y).toInt(), Jalali.en(m).toInt(), Jalali.en(d).toInt())) } catch (e: Exception) { "—" }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Color.White, title = { Title("یادآوری جدید") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("مثلاً: قرار با ستاره") })
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Num(y, "سال") { y = it }; Num(m, "ماه") { m = it }; Num(d, "روز") { d = it } }
            Text("📅 روز هفته: $wd", fontWeight = FontWeight.Bold)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Num(h, "ساعت") { h = it }; Text(":", fontSize = 22.sp); Num(mi, "دقیقه") { mi = it }
                }
            }
            Text("تکرار", fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("یک‌بار", "روزانه", "هفتگی", "ماهانه").forEachIndexed { i, s -> FilterChip(rep == i, { rep = i }, { Text(s, fontSize = 12.sp) }) } }
            if (err) Text("تاریخ یا ساعت نامعتبر است", color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { TextButton({
        try {
            val yy = Jalali.en(y).toInt(); val mm = Jalali.en(m).toInt(); val dd = Jalali.en(d).toInt()
            require(mm in 1..12 && dd in 1..Jalali.monthLen(yy, mm) && title.isNotBlank())
            val at = LocalDateTime.of(Jalali.toDate(yy, mm, dd), LocalTime.of(Jalali.en(h).toInt(), Jalali.en(mi).toInt())).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            onSave(Reminder(System.currentTimeMillis(), title.trim(), at, false, rep))
        } catch (e: Exception) { err = true }
    }) { Text("ذخیره", color = Ink) } }, dismissButton = { TextButton(onDismiss) { Text("انصراف", color = Ink) } })
}

@Composable fun MoodScreen() {
    val c = LocalContext.current
    var moods by remember { mutableStateOf(Store.moods(c)) }
    val today = LocalDate.now(); val td = today.toEpochDay()
    fun avg(n: Int): Int? { val v = (0 until n).flatMap { moods[td - it]?.filter { x -> x >= 0 } ?: emptyList() }; return if (v.isEmpty()) null else v.sum() * 25 / v.size }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GradCard(Modifier.fillMaxWidth()) {
            Title("حالت امروز چطوره؟ (${Jalali.dayName(today)})")
            listOf("نوبت اول", "نوبت دوم").forEachIndexed { slot, name ->
                Text(name, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
                Faces(moods[td]?.get(slot)?.takeIf { it >= 0 }) { lv -> Store.putMood(c, td, slot, lv); moods = Store.moods(c) }
            }
        }
        GradCard(Modifier.fillMaxWidth()) {
            Title("میانگین حال و هوا")
            listOf("روزانه" to 1, "هفتگی (۷ روز اخیر)" to 7, "ماهانه (۳۰ روز اخیر)" to 30, "سالانه (۳۶۵ روز اخیر)" to 365).forEach { (name, n) ->
                val a = avg(n)
                Text(if (a == null) "$name: —" else Jalali.fa("$name: $a٪ ${moodEmoji[((a + 12) / 25).coerceIn(0, 4)]}"), Modifier.padding(top = 10.dp))
                LinearProgressIndicator(progress = { (a ?: 0) / 100f }, Modifier.fillMaxWidth().padding(top = 4.dp), color = Ink, trackColor = Color.White)
            }
        }
        GradCard(Modifier.fillMaxWidth()) {
            Title("۷ روز اخیر")
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                (6 downTo 0).forEach { k ->
                    val v = moods[td - k]?.filter { it >= 0 } ?: emptyList()
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (v.isEmpty()) "·" else v.joinToString("") { moodEmoji[it] }, fontSize = 16.sp)
                        Text(Jalali.fa(Jalali.of(today.minusDays(k.toLong())).third), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable fun SettingsScreen() {
    val c = LocalContext.current
    var times by remember { mutableStateOf(Store.moodTimes(c)) }
    fun msg(t: String) = Toast.makeText(c, t, Toast.LENGTH_LONG).show()
    val out = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) try { c.contentResolver.openOutputStream(u)!!.use { it.write(Store.backup(c).toByteArray()) }; msg("پشتیبان ذخیره شد ✅") } catch (e: Exception) { msg("خطا در ذخیره فایل") }
    }
    val inp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) try { Store.restore(c, c.contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }); times = Store.moodTimes(c); msg("اطلاعات بازیابی شد ✅") } catch (e: Exception) { msg("فایل نامعتبر است") }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GradCard(Modifier.fillMaxWidth()) {
            Title("ساعت‌های پرسیدن حال و هوا")
            Text("در این ساعت‌ها هر روز یه پنجره میاد و می‌پرسه الان حالت چطوره.", fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            times.forEach { m -> Row(verticalAlignment = Alignment.CenterVertically) {
                Text("⏰ " + Jalali.fa("%02d:%02d".format(m / 60, m % 60)), Modifier.weight(1f))
                TextButton({ MoodAlarms.cancel(c, m); times = times - m; Store.setMoodTimes(c, times) }) { Text("🗑") }
            } }
            Button({ TimePickerDialog(c, { _, hh, mm -> val t = hh * 60 + mm; if (t !in times) { times = (times + t).sorted(); Store.setMoodTimes(c, times); MoodAlarms.set(c, t) } }, 12, 0, true).show() },
                colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text("＋ افزودن ساعت") }
        }
        GradCard(Modifier.fillMaxWidth()) {
            Title("صدای اعلان‌ها")
            Text("هر کدوم رو جدا باز کن و توی تنظیمات گوشی «Sound» رو بزن تا آهنگ دلخواه رو انتخاب کنی.", fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            OutlinedButton({ Notifs.openChannel(c, "rem") }, Modifier.fillMaxWidth()) { Text("🎵 صدای یادآوری‌ها", color = Ink) }
            OutlinedButton({ Notifs.openChannel(c, "mood") }, Modifier.fillMaxWidth()) { Text("🎵 صدای حال و هوا", color = Ink) }
        }
        GradCard(Modifier.fillMaxWidth()) {
            Title("پشتیبان‌گیری")
            Text("فایل پشتیبان رو توی Google Drive یا تلگرام نگه دار و روی گوشی جدید بازیابی کن.", fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            Button({ out.launch("planner-backup.json") }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text("📤 ذخیره فایل پشتیبان") }
            OutlinedButton({ inp.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("📥 بازیابی از فایل پشتیبان", color = Ink) }
        }
    }
}
