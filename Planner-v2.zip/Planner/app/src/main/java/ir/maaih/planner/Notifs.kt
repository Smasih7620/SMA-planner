package ir.maaih.planner
import android.app.*
import android.content.*
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import java.time.*

object Notifs {
    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rem", "یادآوری‌ها", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("mood", "حال و هوا", NotificationManager.IMPORTANCE_HIGH))
    }
    fun openChannel(c: Context, id: String) {
        channels(c)
        c.startActivity(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName).putExtra(Settings.EXTRA_CHANNEL_ID, id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

object Alarms {
    fun schedule(c: Context, at: Long, pi: PendingIntent) {
        val am = c.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }
    private fun pi(c: Context, r: Reminder) = PendingIntent.getBroadcast(c, (r.id % Int.MAX_VALUE).toInt(),
        Intent(c, AlarmReceiver::class.java).putExtra("i", r.id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun set(c: Context, r: Reminder) {
        if (r.at <= System.currentTimeMillis() || (r.done && r.repeat == 0)) return
        schedule(c, r.at, pi(c, r))
    }
    fun cancel(c: Context, r: Reminder) = c.getSystemService(AlarmManager::class.java).cancel(pi(c, r))
}

object MoodAlarms {
    private fun pi(c: Context, m: Int) = PendingIntent.getBroadcast(c, 900000 + m,
        Intent(c, MoodReceiver::class.java).putExtra("m", m), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun set(c: Context, m: Int) {
        var t = LocalDate.now().atTime(m / 60, m % 60)
        if (!t.isAfter(LocalDateTime.now().plusSeconds(5))) t = t.plusDays(1)
        Alarms.schedule(c, t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), pi(c, m))
    }
    fun cancel(c: Context, m: Int) = c.getSystemService(AlarmManager::class.java).cancel(pi(c, m))
    fun syncAll(c: Context) = Store.moodTimes(c).forEach { set(c, it) }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("i", 0); val r = Store.reminders(c).find { it.id == id } ?: return
        if (!r.done) {
            Notifs.channels(c)
            val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            c.getSystemService(NotificationManager::class.java).notify(System.nanoTime().toInt(), NotificationCompat.Builder(c, "rem")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("⏰ یادآوری").setContentText(r.title)
                .setAutoCancel(true).setContentIntent(open).setPriority(NotificationCompat.PRIORITY_HIGH).build())
        }
        Store.advance(c, id); ReminderWidget.refresh(c)
    }
}

class MoodReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Notifs.channels(c); MoodAlarms.set(c, i.getIntExtra("m", 0))
        val pi = PendingIntent.getActivity(c, 1, Intent(c, MoodPromptActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        c.getSystemService(NotificationManager::class.java).notify(777, NotificationCompat.Builder(c, "mood")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("😊 الان حالت چطوره؟").setContentText("لمس کن و حال و هوات رو ثبت کن")
            .setAutoCancel(true).setContentIntent(pi).setFullScreenIntent(pi, true).setPriority(NotificationCompat.PRIORITY_HIGH).build())
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.normalize(c); Store.reminders(c).forEach { Alarms.set(c, it) }; MoodAlarms.syncAll(c); ReminderWidget.refresh(c)
    }
}
