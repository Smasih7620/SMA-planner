package ir.maaih.planner
import android.app.*
import android.appwidget.AppWidgetManager
import android.content.*
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import org.json.*

data class Reminder(val id: Long, val title: String, val at: Long, val done: Boolean = false)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("d", 0)
    fun reminders(c: Context): List<Reminder> {
        val a = JSONArray(p(c).getString("r", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it); Reminder(o.getLong("id"), o.getString("t"), o.getLong("a"), o.getBoolean("d")) }.sortedBy { it.at }
    }
    fun saveReminders(c: Context, l: List<Reminder>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("id", it.id).put("t", it.title).put("a", it.at).put("d", it.done)) }
        p(c).edit().putString("r", a.toString()).apply(); ReminderWidget.refresh(c)
    }
    fun moods(c: Context): Map<Long, Int> { val o = JSONObject(p(c).getString("m", "{}")); return o.keys().asSequence().associate { it.toLong() to o.getInt(it) } }
    fun backup(c: Context): String = JSONObject().put("r", JSONArray(p(c).getString("r", "[]"))).put("m", JSONObject(p(c).getString("m", "{}"))).toString()
    fun restore(c: Context, s: String) {
        val o = JSONObject(s); val r = o.getJSONArray("r"); val m = o.getJSONObject("m")
        p(c).edit().putString("r", r.toString()).putString("m", m.toString()).apply()
        reminders(c).forEach { Alarms.set(c, it) }; ReminderWidget.refresh(c)
    }
    fun setMood(c: Context, day: Long, lv: Int) { val o = JSONObject(p(c).getString("m", "{}")); o.put(day.toString(), lv); p(c).edit().putString("m", o.toString()).apply() }
}

object Alarms {
    private fun pi(c: Context, r: Reminder) = PendingIntent.getBroadcast(c, (r.id % Int.MAX_VALUE).toInt(),
        Intent(c, AlarmReceiver::class.java).putExtra("t", r.title), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun set(c: Context, r: Reminder) {
        if (r.at <= System.currentTimeMillis() || r.done) return
        val am = c.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi(c, r))
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi(c, r))
    }
    fun cancel(c: Context, r: Reminder) = c.getSystemService(AlarmManager::class.java).cancel(pi(c, r))
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rem", "یادآوری", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(System.nanoTime().toInt(), NotificationCompat.Builder(c, "rem")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("⏰ یادآوری")
            .setContentText(i.getStringExtra("t")).setAutoCancel(true).setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_HIGH).build())
        ReminderWidget.refresh(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Store.reminders(c).forEach { Alarms.set(c, it) }; ReminderWidget.refresh(c) }
}

class ReminderWidget : android.appwidget.AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = refresh(c)
    companion object {
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, ReminderWidget::class.java)); if (ids.isEmpty()) return
            val now = System.currentTimeMillis()
            val up = Store.reminders(c).filter { !it.done && it.at >= now - 3600000 }.take(6)
            val rv = RemoteViews(c.packageName, R.layout.widget)
            rv.setTextViewText(R.id.w_text, if (up.isEmpty()) "یادآوری‌ای نیست ✨" else up.joinToString("\n") { "• ${Jalali.fmt(it.at)}  ${it.title}" })
            rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            ids.forEach { m.updateAppWidget(it, rv) }
        }
    }
}
