@file:OptIn(ExperimentalMaterial3Api::class)
package ir.maaih.planner
import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.*

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { MaterialTheme { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() } } }
    }
}

@Composable fun App() {
    var tab by remember { mutableStateOf(0) }
    Scaffold(bottomBar = { NavigationBar {
        NavigationBarItem(tab == 0, { tab = 0 }, { Text("📅", fontSize = 20.sp) }, label = { Text("برنامه") })
        NavigationBarItem(tab == 1, { tab = 1 }, { Text("😊", fontSize = 20.sp) }, label = { Text("حال و هوا") })
        NavigationBarItem(tab == 2, { tab = 2 }, { Text("💾", fontSize = 20.sp) }, label = { Text("پشتیبان") })
    } }) { pad -> Box(Modifier.padding(pad)) { when (tab) { 0 -> PlanScreen(); 1 -> MoodScreen(); else -> BackupScreen() } } }
}

@Composable fun PlanScreen() {
    val c = LocalContext.current
    var list by remember { mutableStateOf(Store.reminders(c)) }
    var range by remember { mutableStateOf(0) }
    var show by remember { mutableStateOf(false) }
    fun save(l: List<Reminder>) { list = l.sortedBy { it.at }; Store.saveReminders(c, list) }
    val today = LocalDate.now(); val z = ZoneId.systemDefault()
    val (from, to) = when (range) {
        0 -> today to today.plusDays(1)
        1 -> { val s = today.minusDays(((today.dayOfWeek.value + 1) % 7).toLong()); s to s.plusDays(7) }
        else -> { val j = Jalali.of(today); val ny = if (j.second == 12) j.first + 1 else j.first; val nm = if (j.second == 12) 1 else j.second + 1
            Jalali.toDate(j.first, j.second, 1) to Jalali.toDate(ny, nm, 1) }
    }
    val f = from.atStartOfDay(z).toInstant().toEpochMilli(); val t = to.atStartOfDay(z).toInstant().toEpochMilli()
    val shown = list.filter { it.at in f until t }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text(Jalali.fmtDate(today), style = MaterialTheme.typography.headlineSmall)
            Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("امروز", "این هفته", "این ماه").forEachIndexed { i, s -> FilterChip(range == i, { range = i }, { Text(s) }) }
            }
            if (shown.isEmpty()) Text("یادآوری‌ای ثبت نشده ✨", Modifier.padding(top = 24.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(r.done, { d -> val n = r.copy(done = d); if (d) Alarms.cancel(c, r) else Alarms.set(c, n); save(list.map { if (it.id == r.id) n else it }) })
                        Column(Modifier.weight(1f)) { Text(r.title, style = MaterialTheme.typography.titleMedium); Text(Jalali.fmt(r.at), style = MaterialTheme.typography.bodySmall) }
                        TextButton({ Alarms.cancel(c, r); save(list.filter { it.id != r.id }) }) { Text("🗑") }
                    } }
                }
            }
        }
        FloatingActionButton({ show = true }, Modifier.align(Alignment.BottomStart).padding(16.dp)) { Text("＋", fontSize = 24.sp) }
    }
    if (show) AddDialog({ show = false }) { r -> Alarms.set(c, r); save(list + r); show = false }
}

@Composable fun RowScope.Num(v: String, label: String, set: (String) -> Unit) =
    OutlinedTextField(v, set, Modifier.weight(1f), label = { Text(label) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))

@Composable fun AddDialog(onDismiss: () -> Unit, onSave: (Reminder) -> Unit) {
    val now = LocalDateTime.now(); val j = Jalali.of(now.toLocalDate())
    var title by remember { mutableStateOf("") }
    var y by remember { mutableStateOf(j.first.toString()) }; var m by remember { mutableStateOf(j.second.toString()) }; var d by remember { mutableStateOf(j.third.toString()) }
    var h by remember { mutableStateOf(now.hour.toString()) }; var mi by remember { mutableStateOf("0") }
    var err by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("یادآوری جدید") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("مثلاً: قرار با ستاره") })
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Num(y, "سال") { y = it }; Num(m, "ماه") { m = it }; Num(d, "روز") { d = it } }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Num(h, "ساعت") { h = it }; Num(mi, "دقیقه") { mi = it } }
        if (err) Text("تاریخ یا ساعت نامعتبر است", color = MaterialTheme.colorScheme.error)
    } }, confirmButton = { TextButton({
        try {
            val yy = Jalali.en(y).toInt(); val mm = Jalali.en(m).toInt(); val dd = Jalali.en(d).toInt()
            require(mm in 1..12 && dd in 1..Jalali.monthLen(yy, mm) && title.isNotBlank())
            val at = LocalDateTime.of(Jalali.toDate(yy, mm, dd), LocalTime.of(Jalali.en(h).toInt(), Jalali.en(mi).toInt())).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            onSave(Reminder(System.currentTimeMillis(), title.trim(), at))
        } catch (e: Exception) { err = true }
    }) { Text("ذخیره") } }, dismissButton = { TextButton(onDismiss) { Text("انصراف") } })
}

val moodEmoji = listOf("😭", "😞", "😐", "🙂", "🤩")
val moodName = listOf("خیلی بد", "بد", "نرمال", "خوب", "عالی")

@Composable fun MoodScreen() {
    val c = LocalContext.current
    var moods by remember { mutableStateOf(Store.moods(c)) }
    val today = LocalDate.now(); val td = today.toEpochDay()
    fun avg(days: Int): Int? { val v = (0 until days).mapNotNull { moods[td - it] }; return if (v.isEmpty()) null else v.sum() * 25 / v.size }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("امروز حالت چطوره؟", style = MaterialTheme.typography.headlineSmall)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            moodEmoji.forEachIndexed { i, e ->
                val sel = moods[td] == i
                Card(onClick = { Store.setMood(c, td, i); moods = Store.moods(c) },
                    colors = CardDefaults.cardColors(containerColor = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(e, fontSize = 30.sp); Text(moodName[i], fontSize = 11.sp); Text(Jalali.fa("${i * 25}٪"), fontSize = 11.sp)
                    }
                }
            }
        }
        Text("میانگین حال و هوا", style = MaterialTheme.typography.titleMedium)
        listOf("روزانه" to 1, "هفتگی (۷ روز)" to 7, "ماهانه (۳۰ روز)" to 30).forEach { (name, n) ->
            val a = avg(n)
            Column { Text(if (a == null) "$name: —" else Jalali.fa("$name: $a٪ ${moodEmoji[((a + 12) / 25).coerceIn(0, 4)]}"))
                LinearProgressIndicator(progress = { (a ?: 0) / 100f }, Modifier.fillMaxWidth().padding(top = 4.dp)) }
        }
        Text("۷ روز اخیر", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            (6 downTo 0).forEach { k -> val d = today.minusDays(k.toLong())
                Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(moods[td - k]?.let { moodEmoji[it] } ?: "·", fontSize = 24.sp); Text(Jalali.fa(Jalali.of(d).third.toString()), fontSize = 11.sp) } }
        }
    }
}

@Composable fun BackupScreen() {
    val c = LocalContext.current
    fun msg(t: String) = Toast.makeText(c, t, Toast.LENGTH_LONG).show()
    val out = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) try { c.contentResolver.openOutputStream(u)!!.use { it.write(Store.backup(c).toByteArray()) }; msg("پشتیبان ذخیره شد ✅") } catch (e: Exception) { msg("خطا در ذخیره فایل") }
    }
    val inp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) try { Store.restore(c, c.contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }); msg("اطلاعات بازیابی شد ✅") } catch (e: Exception) { msg("فایل نامعتبر است") }
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("💾 پشتیبان‌گیری", style = MaterialTheme.typography.headlineSmall)
        Text("یادآوری‌ها و حال و هواهات توی یه فایل ذخیره می‌شه. اون فایل رو توی Google Drive یا تلگرام نگه دار و روی گوشی جدید بازیابی کن.")
        Button({ out.launch("planner-backup.json") }, Modifier.fillMaxWidth()) { Text("📤 ذخیره فایل پشتیبان") }
        OutlinedButton({ inp.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("📥 بازیابی از فایل پشتیبان") }
    }
}
