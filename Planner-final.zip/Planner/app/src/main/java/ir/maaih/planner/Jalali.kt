package ir.maaih.planner
import java.time.*

object Jalali {
    val months = listOf("فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند")
    fun fa(s: String) = s.map { if (it in '0'..'9') ('۰' + (it - '0')) else it }.joinToString("")
    fun en(s: String) = s.map { if (it in '۰'..'۹') ('0' + (it - '۰')) else it }.joinToString("")

    fun of(d: LocalDate): Triple<Int, Int, Int> {
        val gdm = intArrayOf(0,31,59,90,120,151,181,212,243,273,304,334)
        val gy = d.year; val gm = d.monthValue; val gd = d.dayOfMonth
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365*gy + (gy2+3)/4 - (gy2+99)/100 + (gy2+399)/400 + gd + gdm[gm-1]
        var jy = -1595 + 33*(days/12053); days %= 12053
        jy += 4*(days/1461); days %= 1461
        if (days > 365) { jy += (days-1)/365; days = (days-1)%365 }
        val jm = if (days < 186) 1 + days/31 else 7 + (days-186)/30
        val jd = 1 + (if (days < 186) days%31 else (days-186)%30)
        return Triple(jy, jm, jd)
    }
    fun toDate(jy: Int, jm: Int, jd: Int): LocalDate {
        val jy2 = jy + 1595
        var days = -355668 + 365*jy2 + (jy2/33)*8 + ((jy2%33)+3)/4 + jd + (if (jm < 7) (jm-1)*31 else (jm-7)*30 + 186)
        var gy = 400*(days/146097); days %= 146097
        if (days > 36524) { days--; gy += 100*(days/36524); days %= 36524; if (days >= 365) days++ }
        gy += 4*(days/1461); days %= 1461
        if (days > 365) { gy += (days-1)/365; days = (days-1)%365 }
        var gd = days + 1
        val sal = intArrayOf(0,31,if ((gy%4==0 && gy%100!=0) || gy%400==0) 29 else 28,31,30,31,30,31,31,30,31,30,31)
        var gm = 0
        while (gm < 13 && gd > sal[gm]) { gd -= sal[gm]; gm++ }
        return LocalDate.of(gy, gm, gd)
    }
    fun monthLen(y: Int, m: Int) = when {
        m <= 6 -> 31; m <= 11 -> 30
        of(toDate(y, 12, 30)) == Triple(y, 12, 30) -> 30; else -> 29
    }
    fun fmtDate(d: LocalDate): String { val j = of(d); return fa("${j.third} ${months[j.second-1]} ${j.first}") }
    fun fmt(ms: Long): String {
        val t = LocalDateTime.ofInstant(Instant.ofEpochMilli(ms), ZoneId.systemDefault())
        val j = of(t.toLocalDate())
        return fa("${j.third} ${months[j.second-1]} - %02d:%02d".format(t.hour, t.minute))
    }
}
